package level2_no6_redo_lab3_level2;

public enum Zone {
	CA, FL, IA, MA, MT, OH, OR, TX, UT, OTHER;
}
