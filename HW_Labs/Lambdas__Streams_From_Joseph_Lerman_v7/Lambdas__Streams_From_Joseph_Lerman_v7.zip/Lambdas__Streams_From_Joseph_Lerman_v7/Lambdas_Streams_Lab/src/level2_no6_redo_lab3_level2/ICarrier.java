package level2_no6_redo_lab3_level2;

public interface ICarrier {
	public double calculateCost();
}
