package level2_no6_redo_lab3_level1;

public interface ICarrier {
	public double calculateCost();
}
