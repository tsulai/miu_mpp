package level2_no5_redo_school_lab2_level2;

public class Person {
	protected String name;
	protected String phone;
	protected int age;
	
	Person(String name, String phone, int age){
		this.name = name;
		this.phone = phone;
		this.age = age;
	}
	public double getSalary() {
		return 0;
	}

}
