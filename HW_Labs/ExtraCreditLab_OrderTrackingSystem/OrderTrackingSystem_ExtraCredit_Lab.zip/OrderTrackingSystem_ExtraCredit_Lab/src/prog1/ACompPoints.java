package prog1;

public abstract class ACompPoints implements ICompPoints {
	public abstract double getPoints();
}
