package prog1;

public interface ICompPoints {
	public double getPoints();
}
