package prog1;

public interface ICustomer {
	public String getCreditRating();
}
