package prog1;

public class AudioVideoPoints extends ACompPoints{
	private double points;
	public AudioVideoPoints() {
		super();
		this.points  = 0.5;
	}
	@Override
	public double getPoints() {
		// TODO Auto-generated method stub
		return points;
	}
}
