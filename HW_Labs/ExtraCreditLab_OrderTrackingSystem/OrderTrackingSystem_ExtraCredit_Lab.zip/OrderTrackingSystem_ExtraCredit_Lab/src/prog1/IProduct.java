package prog1;

public interface IProduct {
	public double getPrice();
}
