package prog1;

public class OtherPoints extends ACompPoints{
	
	private double points;

	public OtherPoints() {
		super();
		this.points = 0.25;
	}

	@Override
	public double getPoints() {
		// TODO Auto-generated method stub
		return points;
	}
}
