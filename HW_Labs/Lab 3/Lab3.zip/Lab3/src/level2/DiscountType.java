package level2;

public enum DiscountType {
	STUDENT,SENIOR;
}
