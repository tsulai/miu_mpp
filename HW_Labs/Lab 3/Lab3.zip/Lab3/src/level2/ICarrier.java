package level2;

public interface ICarrier {
	public double calculateCost();
}
