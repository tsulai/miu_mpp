package level1;

public enum Zone {
	CA, FL, IA, MA, MT, OH, OR, TX, UT, OTHER;
}
