package level1;

public interface ICarrier {
	public double calculateCost();
}
