package level4;

public class Immutable_Test_Extend{ //extends ImmutableContacts {
	public Immutable_Test_Extend(){
		//got error in extending immutable class
	}
}
