package level4;

public enum Size {
	SMALL, MEDIUM, LARGE
}
