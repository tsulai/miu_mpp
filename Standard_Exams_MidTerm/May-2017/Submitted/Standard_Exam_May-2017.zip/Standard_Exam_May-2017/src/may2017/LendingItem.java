package may2017;

public class LendingItem {
	public Integer getNumCopiesInLib() {
		return numCopiesInLib;
	}

	public void setNumCopiesInLib(Integer numCopiesInLib) {
		this.numCopiesInLib = numCopiesInLib;
	}

	private Integer numCopiesInLib;
	
}
