package may2017;

public enum ItemType {
	BOOK, CD;
}
