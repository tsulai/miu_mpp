package apr2017_prob2;

public class SalesDept extends Department{
	//implement - DONE
	@Override
	public String getName() {
		return "Sales";
	}
	
	public void requestMarketingMaterials() {
		//not implemented
	}
}
