package apr2017_prob2;

public class MarketingDept extends Department {
	//implement - DONE
	@Override
	public String getName() {
		return "Marketing";
	}
	public void applyForJob() {
		//not implemented
	}
}
