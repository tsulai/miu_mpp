package apr2017_prob2;

public class BillingDept extends Department {
	//implement - DONE
	@Override
	public String getName() {
		return "Billing";
	}
	public String monthlyReport() {
		//not implemented
		return null;
	}
}
